GRACE PROPOSAL WEBSITE
=======================

Files:
- index.html
- grace-and-abhinandan.jpg

FREE HOSTING WITH GITHUB PAGES
1. Create/sign in to a GitHub account.
2. Create a NEW PUBLIC repository, for example: grace-proposal
3. Upload BOTH files from this folder.
4. Open the repository's Settings.
5. Open Pages.
6. Under Build and deployment, choose "Deploy from a branch".
7. Select the main branch and the / (root) folder, then Save.
8. Wait a few minutes. GitHub will show your website URL on the Pages screen.
9. Open that URL on your phone and send it to Grace.

IMPORTANT:
- Keep the repository PUBLIC if you are using GitHub Pages on the free plan.
- Keep the image filename exactly: grace-and-abhinandan.jpg
